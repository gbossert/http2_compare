# mruby-input-stream

[![Build Status](https://travis-ci.org/takahashim/mruby-input-stream.svg?branch=master)](https://travis-ci.org/takahashim/mruby-input-stream)

Input Stream class for Rack.


## Install

add conf.gem to `build_config.rb`:

    MRuby::Build.new do |conf|
    
      # ... (snip) ...
    
      conf.gem :github => 'takahashim/mruby-input-stream'
    end

## License

MIT

## Author

Masayoshi Takahashi



